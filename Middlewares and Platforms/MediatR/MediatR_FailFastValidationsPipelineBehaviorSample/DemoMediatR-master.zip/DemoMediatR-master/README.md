# DemoMediatR

Projeto de exemplo para os artigos:

* [MediatR com ASP.Net Core](https://www.wellingtonjhn.com/posts/mediatr-com-asp.net-core/)
* [Fail-fast Validations com Pipeline Behavior no MediatR e ASP.Net Core](https://www.wellingtonjhn.com/posts/fail-fast-validations-com-pipeline-behavior-no-mediatr-e-asp.net-core/)
