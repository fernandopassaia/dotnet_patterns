docker-compose up -d

docker-compose ps