docker tag site-azuredevops-t3:1.0 azurenapratica/site-azuredevops-t3:1.0

docker push azurenapratica/site-azuredevops-t3:1.0