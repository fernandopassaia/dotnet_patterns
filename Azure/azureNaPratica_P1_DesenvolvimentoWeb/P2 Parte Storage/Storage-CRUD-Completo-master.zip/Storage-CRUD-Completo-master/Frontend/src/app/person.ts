export interface Person {
    name: string;
    email: string;
    rowKey: string;
    partitionKey: string;
}