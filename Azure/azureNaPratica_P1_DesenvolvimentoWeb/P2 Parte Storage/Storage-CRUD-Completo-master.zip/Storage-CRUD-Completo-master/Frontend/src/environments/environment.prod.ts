export const environment = {
  production: true,
  API: 'https://app-azurenapratica.azurewebsites.net/'
};
