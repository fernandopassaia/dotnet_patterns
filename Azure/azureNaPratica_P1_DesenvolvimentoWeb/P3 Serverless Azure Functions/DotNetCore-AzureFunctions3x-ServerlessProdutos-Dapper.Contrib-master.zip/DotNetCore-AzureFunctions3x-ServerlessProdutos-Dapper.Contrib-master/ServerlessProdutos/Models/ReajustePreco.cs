namespace ServerlessProdutos.Models
{
    public class ReajustePreco
    {
        public double? IndiceReajuste { get; set; }
        public string ObservacaoReajustePreco { get; set; }
    }
}