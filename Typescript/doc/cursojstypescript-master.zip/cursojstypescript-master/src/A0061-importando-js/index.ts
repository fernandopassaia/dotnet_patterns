import { soma } from './modulo';

const result = soma(10, 20) as number;
console.log(result);
