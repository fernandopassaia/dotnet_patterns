export function soma(x, y) {
  return x + y;
}
