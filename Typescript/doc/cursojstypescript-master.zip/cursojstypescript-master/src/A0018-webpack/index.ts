import funcao from './mod';
funcao();
