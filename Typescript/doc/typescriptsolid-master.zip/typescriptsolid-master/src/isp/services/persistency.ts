export class Persistency {
  saveOrder(): void {
    console.log('Pedido salvo com sucesso...');
  }
}
