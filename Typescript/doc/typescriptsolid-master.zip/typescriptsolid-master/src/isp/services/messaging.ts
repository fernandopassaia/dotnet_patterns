export class Messaging {
  sendMessage(msg: string): void {
    console.log('Mensagem enviada:', msg);
  }
}
