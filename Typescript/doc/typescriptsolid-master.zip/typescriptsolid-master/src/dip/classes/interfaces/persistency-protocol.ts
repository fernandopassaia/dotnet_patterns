export interface PersistencyProtocol {
  saveOrder(): void;
}
