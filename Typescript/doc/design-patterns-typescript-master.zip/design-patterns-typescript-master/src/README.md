Essa é apenas a raiz do projeto, então não há nada aqui para ser visto. Os detalhes dos padrões estão dentro de cada uma das pastas com seu nome. Existe um README com a descrição completa do padrão, um (ou mais) diagrama(s) e um trecho de código. Cada padrão está em sua categoria correspondente, são elas: creational (criacionais), behavioural (comportamentais) e structural (estruturais).

Os vídeos descrevendo os padrões são publicados em https://www.youtube.com/watch?v=MqddY6Ochkc&list=PLbIBj8vQhvm0VY5YrMrafWaQY2EnJ3j8H  

Por favor, acompanhe os vídeos para maior entendimento.