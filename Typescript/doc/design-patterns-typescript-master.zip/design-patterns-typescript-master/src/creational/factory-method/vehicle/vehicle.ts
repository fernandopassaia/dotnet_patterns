export interface Vehicle {
  pickUp(customerName: string): void;
  stop(): void;
}
