export function randomNumbers(length: number): number {
  return Math.floor(Math.random() * length);
}
