export interface MealBuilderProtocol {
  makeMeal(): this;
  // makeBeverage(): this;
  // makeDessert(): this;
}
