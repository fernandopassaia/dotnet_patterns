export interface MealCompositeProtocol {
  getPrice(): number;
}
