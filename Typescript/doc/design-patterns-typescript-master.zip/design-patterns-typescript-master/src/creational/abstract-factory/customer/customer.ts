export interface Customer {
  name: string;
}
