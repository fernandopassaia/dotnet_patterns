export interface VehicleProtocol {
  pickUp(): void;
}
