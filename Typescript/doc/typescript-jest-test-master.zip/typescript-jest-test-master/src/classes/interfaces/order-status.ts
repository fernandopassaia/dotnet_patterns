export type OrderStatus = 'open' | 'closed';
