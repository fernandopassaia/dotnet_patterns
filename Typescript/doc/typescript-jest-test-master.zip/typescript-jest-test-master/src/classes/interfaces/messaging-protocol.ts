export interface MessagingProtocol {
  sendMessage(msg: string): void;
}
