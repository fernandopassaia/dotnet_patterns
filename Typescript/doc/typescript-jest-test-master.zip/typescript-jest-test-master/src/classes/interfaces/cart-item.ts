export interface CartItem {
  name: string;
  price: number;
}
